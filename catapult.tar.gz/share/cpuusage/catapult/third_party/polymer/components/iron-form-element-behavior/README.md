
<!---

This README is automatically generated from the comments in these files:
iron-form-element-behavior.html

Edit those files, and our readme bot will duplicate them over here!
Edit this file, and the bot will squash your changes :)

-->

[![Build Status](https://travis-ci.org/PolymerElements/iron-form-element-behavior.svg?branch=master)](https://travis-ci.org/PolymerElements/iron-form-element-behavior)

_[Demo and API Docs](https://elements.polymer-project.org/elements/iron-form-element-behavior)_


##Polymer.IronFormElementBehavior


  Polymer.IronFormElementBehavior enables a custom element to be included
  in an `iron-form`.

  
