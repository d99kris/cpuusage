treebuilders Package
====================

:mod:`treebuilders` Package
---------------------------

.. automodule:: html5lib.treebuilders
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`_base` Module
-------------------

.. automodule:: html5lib.treebuilders._base
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`dom` Module
-----------------

.. automodule:: html5lib.treebuilders.dom
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`etree` Module
-------------------

.. automodule:: html5lib.treebuilders.etree
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`etree_lxml` Module
------------------------

.. automodule:: html5lib.treebuilders.etree_lxml
    :members:
    :undoc-members:
    :show-inheritance:

